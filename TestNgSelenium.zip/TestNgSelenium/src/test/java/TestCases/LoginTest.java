package TestCases;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.Test;

import PageObjects.LoginPage;

public class LoginTest extends BaseClass {

	
	@Test
	public void logintest() throws InterruptedException{
		driver.get(url);
		logger.info("Url Opened");
		LoginPage lp= new LoginPage(driver);
		lp.setUserName(uname);
		logger.info("Entered Username");
		lp.setPassword(upwd);
		lp.ClickLoginButton();
		Thread.sleep(2000);
		if(driver.getTitle().equals("Find a Flight: Mercury Tours:"))
				{
			Assert.assertTrue(true);
				}
		else{
			Assert.assertTrue(false);
		}
	}
	
}
