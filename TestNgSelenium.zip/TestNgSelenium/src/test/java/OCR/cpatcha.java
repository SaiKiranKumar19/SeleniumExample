package OCR;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class cpatcha {

	public static WebDriver driver;
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sai kiran kumar\\workspace\\Real\\Drivers\\chromedriver.exe");
		 		ChromeOptions opt = new ChromeOptions();
				opt.addArguments("--disable-notifications");
				driver = new ChromeDriver(opt);
				driver.manage().window().maximize();
		driver.navigate().to("https://www.irctc.co.in/nget/train-search");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("loginText")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//driver.findElement(By.id("userId")).sendKeys("cakumar92");
		//driver.findElement(By.id("pwd")).sendKeys("cgu385");
	File img=	driver.findElement(By.id("captchaImg")).getScreenshotAs(OutputType.FILE);
	String path = System.getProperty("user.dir")+"/screenshots/cpatcha.png";
	try {
		FileHandler.copy(img,new File("path"));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	ITesseract image = new Tesseract();
	image.setDatapath("C:/Users/sai kiran kumar/workspace/Real/tessdata");
	try {
		String str =image.doOCR(new File("path"));
		String []s=str.split(":");
		String x =s[1].replaceAll("^a-zA-Z0-9","");
		System.out.println(x);
		driver.findElement(By.id("nlpAnswer")).sendKeys(x);
	} catch (TesseractException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
