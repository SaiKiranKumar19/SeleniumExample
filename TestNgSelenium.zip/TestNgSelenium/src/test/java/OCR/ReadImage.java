package OCR;

import java.io.File;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class ReadImage {

	public static void main(String[] args) {
	 
		ITesseract image = new Tesseract();
		image.setDatapath("C:/Users/sai kiran kumar/workspace/Real/tessdata");
		try {
			String str =image.doOCR(new File("C:\\Users\\sai kiran kumar\\Desktop\\sample.png"));
			System.out.println(str);
		} catch (TesseractException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
