package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	WebDriver ldriver;
	
	public LoginPage(WebDriver rdriver){
		ldriver = rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	@FindBy(name="userName")
	WebElement UserName;
	
	@FindBy(name="password")
	WebElement Pwd;
	
	@FindBy(name="login")
	WebElement BtnLogin;
	
	public void setUserName(String uname){
		UserName.sendKeys(uname);
	}
	public void setPassword(String pwd){
		Pwd.sendKeys(pwd);
	}
	public void ClickLoginButton(){
		BtnLogin.click();
	}
	
}
